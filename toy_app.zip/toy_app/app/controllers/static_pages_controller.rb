class StaticPagesController < ApplicationController
  def home
  end

  def help
  end
end
